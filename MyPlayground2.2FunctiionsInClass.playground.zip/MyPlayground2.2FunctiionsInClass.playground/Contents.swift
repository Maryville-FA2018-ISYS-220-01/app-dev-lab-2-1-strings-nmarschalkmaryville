//func is how you declare a function

//func functionName (parameters) -> ReturnType {
    //body of function would go here
//}

// No parameters tieMyShoes()

//func functionNamemakeBreakfast (makeBreakfast(food: ["cereal", "toast"])) ->  {}

    
    //makeBreakfast(food: ["eggs", "orange juice"])

//func displayPi() {
  //  print("3.1415")
//}

//displayPi()

//Parameters

//function called triple that triples integers

//func triple(value:Int) {
  //  let result = value * 3
    //print("If you multiple \(value) by 3, you'll get \(result).")
//}

//triple(value: 10)

//Multiple arguments in one function, need to separate each parameter with a comma.

func multiply(firstNumber: Int, secondNumber: Int) {
    let result = firstNumber * secondNumber
    print("the result is \(result).")
}

multiply(firstNumber: 10, secondNumber: 5)

